Title: Ultimate browser detect (Safari, Chrome, Firefox, IE, Opera)
Description: We have all seen scripts that detect browsers, but how about one that is updated and covers all the most popular browsers, and display a sleek icon depending on which browser is in fact being used. Supported browsers: Chrome, Safari, Firefox, Internet Explorer, and Opera
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=6632&lngWId=2

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
